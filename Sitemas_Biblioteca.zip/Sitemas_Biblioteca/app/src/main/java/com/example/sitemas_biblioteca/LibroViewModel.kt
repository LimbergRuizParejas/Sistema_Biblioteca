package com.example.sistemas_biblioteca

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class LibroViewModel : ViewModel() {
    val libros = MutableLiveData<List<Libro>>()
    val generos = MutableLiveData<List<Genero>>()
    val errorMessage = MutableLiveData<String>()

    init {
        fetchLibros()
        fetchGeneros()
    }

    fun fetchLibros() {
        viewModelScope.launch {
            try {
                val librosList = RetrofitClient.apiService.getLibros().sortedByDescending { it.calificacion }
                libros.value = librosList
            } catch (e: Exception) {
                errorMessage.value = "Error fetching libros: ${e.message}"
            }
        }
    }

    fun fetchGeneros() {
        viewModelScope.launch {
            try {
                val generosList = RetrofitClient.apiService.getGeneros()
                generos.value = generosList
            } catch (e: Exception) {
                errorMessage.value = "Error fetching generos: ${e.message}"
            }
        }
    }

    fun fetchLibrosByGenero(generoId: Int) {
        viewModelScope.launch {
            try {
                val librosList = RetrofitClient.apiService.getLibrosByGenero(generoId)
                libros.value = librosList
            } catch (e: Exception) {
                errorMessage.value = "Error fetching libros by genero: ${e.message}"
            }
        }
    }

    fun addLibro(libro: Libro) {
        viewModelScope.launch {
            try {
                RetrofitClient.apiService.addLibro(libro)
                fetchLibros() // Refresh the list
            } catch (e: Exception) {
                errorMessage.value = "Error adding libro: ${e.message}"
            }
        }
    }

    fun updateLibro(id: Int, libro: Libro) {
        viewModelScope.launch {
            try {
                RetrofitClient.apiService.updateLibro(id, libro)
                fetchLibros() // Refresh the list
            } catch (e: Exception) {
                errorMessage.value = "Error updating libro: ${e.message}"
            }
        }
    }

    fun deleteLibro(id: Int) {
        viewModelScope.launch {
            try {
                RetrofitClient.apiService.deleteLibro(id)
                fetchLibros() // Refresh the list
            } catch (e: Exception) {
                errorMessage.value = "Error deleting libro: ${e.message}"
            }
        }
    }

    fun addGenero(genero: Genero) {
        viewModelScope.launch {
            try {
                RetrofitClient.apiService.addGenero(genero)
                fetchGeneros() // Refresh the list
            } catch (e: Exception) {
                errorMessage.value = "Error adding genero: ${e.message}"
            }
        }
    }

    fun updateGenero(id: Int, genero: Genero) {
        viewModelScope.launch {
            try {
                RetrofitClient.apiService.updateGenero(id, genero)
                fetchGeneros() // Refresh the list
            } catch (e: Exception) {
                errorMessage.value = "Error updating genero: ${e.message}"
            }
        }
    }

    fun deleteGenero(id: Int) {
        viewModelScope.launch {
            try {
                RetrofitClient.apiService.deleteGenero(id)
                fetchGeneros() // Refresh the list
            } catch (e: Exception) {
                errorMessage.value = "Error deleting genero: ${e.message}"
            }
        }
    }
}
