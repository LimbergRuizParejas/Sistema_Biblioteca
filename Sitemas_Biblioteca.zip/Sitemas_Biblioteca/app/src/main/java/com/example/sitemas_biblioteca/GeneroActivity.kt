package com.example.sitemas_biblioteca


import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast
import com.example.sistemas_biblioteca.LibroViewModel
import com.example.sistemas_biblioteca.R

class GeneroActivity : AppCompatActivity() {

    private val libroViewModel: LibroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_genero)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val adapter = GeneroAdapter { genero ->
            val intent = Intent(this, GeneroDetailActivity::class.java).apply {
                putExtra("GENERO_ID", genero.id)
            }
            startActivity(intent)
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        libroViewModel.generos.observe(this, Observer { generos ->
            generos?.let { adapter.submitList(it) }
        })

        libroViewModel.errorMessage.observe(this, Observer { message ->
            message?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        })
    }
}
