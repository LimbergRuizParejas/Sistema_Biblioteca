package com.example.sitemas_biblioteca

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast
import com.example.sistemas_biblioteca.LibroViewModel
import com.example.sistemas_biblioteca.R

class GeneroDetailActivity : AppCompatActivity() {

    private val libroViewModel: LibroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_genero_detail)

        val generoId = intent.getIntExtra("GENERO_ID", -1)
        if (generoId != -1) {
            libroViewModel.fetchLibrosByGenero(generoId)
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val adapter = LibroAdapter { libro ->
            // Acciones para el click en libro
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        libroViewModel.libros.observe(this, Observer { libros ->
            libros?.let { adapter.submitList(it) }
        })

        libroViewModel.errorMessage.observe(this, Observer { message ->
            message?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        })
    }
}
