package com.example.sistemas_biblioteca

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.sistemas_biblioteca.databinding.ItemLibroBinding
import com.squareup.picasso.Picasso

class LibroAdapter(private val onClick: (Libro) -> Unit) : ListAdapter<Libro, LibroAdapter.LibroViewHolder>(LibroDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LibroViewHolder {
        val binding = ItemLibroBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LibroViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LibroViewHolder, position: Int) {
        holder.bind(getItem(position), onClick)
    }

    class LibroViewHolder(private val binding: ItemLibroBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(libro: Libro, onClick: (Libro) -> Unit) {
            binding.libro = libro
            binding.root.setOnClickListener { onClick(libro) }
            Picasso.get().load(libro.urlImagen).into(binding.imageView)
            binding.executePendingBindings()
        }
    }

    class LibroDiffCallback : DiffUtil.ItemCallback<Libro>() {
        override fun areItemsTheSame(oldItem: Libro, newItem: Libro): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Libro, newItem: Libro): Boolean {
            return oldItem == newItem
        }
    }
}
