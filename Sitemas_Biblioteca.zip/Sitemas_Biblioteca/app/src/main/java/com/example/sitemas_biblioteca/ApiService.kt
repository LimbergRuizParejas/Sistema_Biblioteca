package com.example.sistemas_biblioteca

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.DELETE
import retrofit2.http.Body
import retrofit2.http.Path

data class Libro(val id: Int, val nombre: String, val ISBN: String, val urlImagen: String, val sinopsis: String, val precio: Double, val calificacion: Double, val generoId: Int)
data class Genero(val id: Int, val nombre: String)

interface ApiService {
    @GET("libros")
    suspend fun getLibros(): List<Libro>

    @GET("generos")
    suspend fun getGeneros(): List<Genero>

    @GET("generos/{id}/libros")
    suspend fun getLibrosByGenero(@Path("id") generoId: Int): List<Libro>

    @POST("libros")
    suspend fun addLibro(@Body libro: Libro): Libro

    @PUT("libros/{id}")
    suspend fun updateLibro(@Path("id") id: Int, @Body libro: Libro): Libro

    @DELETE("libros/{id}")
    suspend fun deleteLibro(@Path("id") id: Int)

    @POST("generos")
    suspend fun addGenero(@Body genero: Genero): Genero

    @PUT("generos/{id}")
    suspend fun updateGenero(@Path("id") id: Int, @Body genero: Genero): Genero

    @DELETE("generos/{id}")
    suspend fun deleteGenero(@Path("id") id: Int)
}

object RetrofitClient {
    private const val BASE_URL = "https://api.example.com/" // Reemplaza con la URL de tu API

    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
