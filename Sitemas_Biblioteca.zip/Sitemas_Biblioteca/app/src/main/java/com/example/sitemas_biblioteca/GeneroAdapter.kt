package com.example.sitemas_biblioteca

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.sistemas_biblioteca.Genero
import com.example.sistemas_biblioteca.databinding.ItemGeneroBinding
import com.example.sistemas_de_libros.databinding.ItemGeneroBinding

class GeneroAdapter(private val onClick: (Genero) -> Unit) : ListAdapter<Genero, GeneroAdapter.GeneroViewHolder>(GeneroDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GeneroViewHolder {
        val binding = ItemGeneroBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return GeneroViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GeneroViewHolder, position: Int) {
        holder.bind(getItem(position), onClick)
    }

    class GeneroViewHolder(private val binding: ItemGeneroBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(genero: Genero, onClick: (Genero) -> Unit) {
            binding.genero = genero
            binding.root.setOnClickListener { onClick(genero) }
            binding.executePendingBindings()
        }
    }

    class GeneroDiffCallback : DiffUtil.ItemCallback<Genero>() {
        override fun areItemsTheSame(oldItem: Genero, newItem: Genero): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Genero, newItem: Genero): Boolean {
            return oldItem == newItem
        }
    }
}
