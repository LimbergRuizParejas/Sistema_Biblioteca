package com.example.sistemas_biblioteca

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast
import com.example.sitemas_biblioteca.LibroAdapter

class MainActivity : AppCompatActivity() {

    private val libroViewModel: LibroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val adapter = LibroAdapter { libro ->
            val intent = Intent(this, LibroDetailActivity::class.java).apply {
                putExtra("LIBRO_ID", libro.id)
            }
            startActivity(intent)
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        libroViewModel.libros.observe(this, Observer { libros ->
            libros?.let { adapter.submitList(it) }
        })

        libroViewModel.errorMessage.observe(this, Observer { message ->
            message?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        })
    }
}
