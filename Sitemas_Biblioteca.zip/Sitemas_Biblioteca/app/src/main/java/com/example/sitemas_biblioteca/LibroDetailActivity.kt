package com.example.sistemas_biblioteca

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.sistemas_biblioteca.databinding.ActivityLibroDetailBinding
import com.squareup.picasso.Picasso

class LibroDetailActivity : AppCompatActivity() {

    private val libroViewModel: LibroViewModel by viewModels()
    private lateinit var binding: ActivityLibroDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLibroDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val libroId = intent.getIntExtra("LIBRO_ID", -1)
        if (libroId != -1) {
            libroViewModel.libros.observe(this, Observer { libros ->
                libros.find { it.id == libroId }?.let { libro ->
                    binding.libro = libro
                    Picasso.get().load(libro.urlImagen).into(binding.imageView)
                }
            })
        }
    }
}
